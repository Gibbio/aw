#pragma once

namespace as_test {
    extern int MAX_PREFIX_SIZE;
}