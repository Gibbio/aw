#include "test_constants.h"

namespace as_test {
    int MAX_PREFIX_SIZE = 20;
}